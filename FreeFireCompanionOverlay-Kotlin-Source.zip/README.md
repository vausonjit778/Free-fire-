# Companion Guide Overlay (Android / Kotlin)

A small Android Studio project that draws **fixed decorative guide lines** in a transparent overlay. It is not an injector and does not modify, inspect, hook, or communicate with Free Fire.

## Requirements
- Android Studio with Android Gradle Plugin 8.7.3 support
- JDK 17
- Android 8.0 (API 26) or newer

## Build
1. Open this folder in Android Studio.
2. Allow Gradle to sync.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated APK on your Android device.

## Use
1. Open **Companion Guide Overlay**.
2. Tap **Start guide lines**.
3. Android opens the special-app-access screen. Enable **Display over other apps**.
4. Return to the app and tap **Start guide lines** again.
5. Tap **Stop guide lines** in the companion app to remove the overlay.

## Scope and limitations
- Lines are fixed screen decorations, not ESP.
- No player/enemy detection, game-memory access, packet inspection, process injection, or anti-cheat bypass.
- The overlay is independent of Free Fire and is not affiliated with or endorsed by Garena.
