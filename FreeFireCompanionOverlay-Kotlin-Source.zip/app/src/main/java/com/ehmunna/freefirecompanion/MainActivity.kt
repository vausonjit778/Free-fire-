package com.ehmunna.freefirecompanion

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }

        val title = TextView(this).apply {
            text = "Companion Guide Overlay"
            textSize = 24f
        }
        val description = TextView(this).apply {
            text = "Displays fixed decorative guide lines over other apps. " +
                "It does not read game data, detect players, or interact with Free Fire."
            textSize = 16f
            setPadding(0, 20, 0, 24)
        }
        val start = Button(this).apply {
            text = "Start guide lines"
            setOnClickListener { startOverlay() }
        }
        val stop = Button(this).apply {
            text = "Stop guide lines"
            setOnClickListener {
                stopService(Intent(this@MainActivity, GuideOverlayService::class.java))
                Toast.makeText(this@MainActivity, "Overlay stopped", Toast.LENGTH_SHORT).show()
            }
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Allow display over other apps, then tap Start again.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, GuideOverlayService::class.java))
        Toast.makeText(this, "Guide overlay started", Toast.LENGTH_SHORT).show()
    }
}
