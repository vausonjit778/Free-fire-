package com.ehmunna.freefirecompanion

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class GuideOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var guideView: GuideLinesView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        guideView = GuideLinesView(this)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        windowManager.addView(guideView, params)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_NOT_STICKY

    override fun onDestroy() {
        guideView?.let {
            if (it.isAttachedToWindow) windowManager.removeView(it)
        }
        guideView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

private class GuideLinesView(context: Context) : View(context) {
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 220, 255)
        strokeWidth = 3.5f
        style = Paint.Style.STROKE
        alpha = 190
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 28f
        style = Paint.Style.FILL
        alpha = 210
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val originX = w / 2f
        val originY = h * 0.88f

        // Fixed decorative guide lines only; no game entities are detected.
        val targets = listOf(
            w * 0.18f to h * 0.30f,
            w * 0.38f to h * 0.22f,
            w * 0.62f to h * 0.22f,
            w * 0.82f to h * 0.30f
        )
        targets.forEach { (x, y) ->
            canvas.drawLine(originX, originY, x, y, linePaint)
            canvas.drawCircle(x, y, 8f, linePaint)
        }
        canvas.drawText("GUIDE OVERLAY", 24f, 44f, labelPaint)
    }
}
